/*drop procedure if exists proc;
delimiter $
create procedure proc(x int)
begin
select * from emp;
select ename,sal,job,deptno from emp where deptno=x;
end $
delimiter ;*/
/*
drop procedure if exists proc;
delimiter $
create procedure proc()
begin
select dept.deptno,ename,dname from emp,dept where emp.deptno=dept.deptno;
end $
delimiter ;*/
/*
drop procedure if exists proc;
delimiter $
create procedure proc( x int)
begin
declare a int ;
select distinct deptno into a from emp where deptno=x;
if a  is not null then
select ename,sal,job,deptno from emp where deptno=a;
else 
select "record not found " as message;
end if;
end $
delimiter ;


drop procedure if exists proc;
delimiter $
create procedure proc( _tname varchar(20))
begin
drop table if exists _tname;
create table _tname (id int primary key, name varchar(20));
end $
delimiter ;
*/

drop procedure if exists proc;
delimiter $
create procedure proc( x int, nm varchar(20))
begin
declare a int default 0;
drop table if exists _tname;
create table _tname (id int primary key, name varchar(20));
lbl1: loop
insert into _tname values (x,nm);
set a= a + 1;
if a=3 then
	leave lbl1;
end if ;
end loop lbl1;


end $
delimiter ;


