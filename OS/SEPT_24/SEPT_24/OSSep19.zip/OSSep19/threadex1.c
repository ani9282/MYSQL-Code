
 #include<stdio.h>

 void main()
 {
	//sequential execution --single thread execution
	// after first loop is over then start second loop
	while(1) { printf("editor of word ...\n"); }
	while(1) { printf("spellchecker of word ...\n"); }

 }
