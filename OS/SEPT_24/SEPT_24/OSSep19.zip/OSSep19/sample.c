#include<stdio.h>


void main()
{

	printf("\nthis is the o/p of sample.c pid=%d\n",getpid());
	
}
