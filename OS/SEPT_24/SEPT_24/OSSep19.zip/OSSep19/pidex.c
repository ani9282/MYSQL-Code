
#include<stdio.h>

void main()
{
	printf("\nthe pid of this process is %d\n",getpid());
	printf("\nthe ppid of this process is %d\n",getppid());
	while(1);
}

