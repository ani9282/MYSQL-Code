echo "enter a string"
read str

if [ $str != "yes" ] # use = and != to compare strings 
then
	echo "$str"
fi
