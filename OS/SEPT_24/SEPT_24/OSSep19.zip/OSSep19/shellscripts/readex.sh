#!/bin/bash


echo "enter a name"
read name

echo "name=$name"
