

echo "enter 2 strings"
read s1 s2

z=$s1$s2

echo "$z"
