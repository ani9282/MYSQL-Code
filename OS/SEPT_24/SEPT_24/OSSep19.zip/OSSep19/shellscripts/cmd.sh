echo "enter a name of file"
read filename

touch $filename

ls
